package todo.quang.mvvm.utils

/** The base URL of the API */
const val BASE_URL: String = "http://127.0.0.1:5000"