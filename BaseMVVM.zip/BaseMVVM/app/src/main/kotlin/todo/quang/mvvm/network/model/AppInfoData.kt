package todo.quang.mvvm.network.model

data class AppInfoData(val data: List<String>, val genre: String)