package todo.quang.mvvm.base

import android.arch.lifecycle.ViewModel
import todo.quang.mvvm.injection.component.ViewModelInjector
import todo.quang.mvvm.injection.module.NetworkModule
import todo.quang.mvvm.ui.post.PostListViewModel
import todo.quang.mvvm.ui.post.PostViewModel

abstract class BaseViewModel : ViewModel() {
}