package todo.quang.mvvm.network

import retrofit2.http.GET
import retrofit2.http.Path
import todo.quang.mvvm.model.AppInfo
import todo.quang.mvvm.network.model.AppInfoData

/**
 * The interface which provides methods to get result of webservices
 */
interface PostApi {
    /**
     * Get the list of the pots from the API
     */
    @GET("/api")
    suspend fun getGenre(@Path("id") id : String): AppInfoData
}