package todo.quang.mvvm.ui.post

import todo.quang.mvvm.base.BaseViewModel

class PostViewModel : BaseViewModel() {
}